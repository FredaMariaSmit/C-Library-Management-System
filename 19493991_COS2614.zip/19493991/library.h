#ifndef LIBRARY_H
#define LIBRARY_H

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <limits>
#include <string>
using namespace std;

//Base class declaration of private member variables and public member functions
class LibraryItem
{
private:
    //private member variables
    string title;
    string author;
    string bookID;
    bool isBorrowed;

public:
    //default constructor
    LibraryItem()
    {
        title = "";
        author = "";
        bookID = "";
        isBorrowed = false;
    }

    //overload constructor
    LibraryItem(string t, string a, string i, bool ib)
    {
        title = t;
        author = a;
        bookID = i;
        isBorrowed = ib;
    }

    //access functions
    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    string getID() const { return bookID; }
    bool   getStatus() const { return isBorrowed; }

    //mutator functions
    void assignTitle()
    {
        cout << "Title: ";
        getline(cin, title);
    }
    void assignAuthor()
    {
        cout << "Author: ";
        getline(cin, author);
    }
    void assignID()
    {
        cout << "Book ID: ";
        getline(cin, bookID);
    }

    //function determines status of item
    //if available, item is borrowed
    bool borrowItem()
    {
        if (isBorrowed) return false;
        isBorrowed = true;
        return true;
    }

    //function to return item
    bool returnItem()
    {
        if (!isBorrowed) return false;
        isBorrowed = false;
        return true;
    }

    //initialiser function for updating items status (available/unavailable)
    void setStatus(bool borrowed)
    {
        isBorrowed = borrowed;
    }

    //displaying information
    virtual void displayInfo() const
    {
        //fetching information using getter functions
        cout << "Title: "  << getTitle()  << endl;
        cout << "Author: " << getAuthor() << endl;
        cout << "Book ID: "<< getID()     << endl;
        cout << "Status: " << (getStatus() ? "Unavailable" : "Available")
             << endl;
    }

    //virtual destructor
    virtual ~LibraryItem() = default;
};

//Book private member variables and public member functions
class Book : public LibraryItem
{
private:
    //relevant attribute for book: genre
    string genre;

public:
    //default constructor
    Book() : LibraryItem()
    {
        genre = "";
    }

    //overload constructor
    Book(string t, string a, string i, bool ib, string g)
        : LibraryItem(t, a, i, ib)
    {
        genre = g;
    }

    //getter function for genre
    string getGenre() const { return genre; }

    //mutator functions for genre
    void assignGenre()
    {
        cout << "Genre: ";
        getline(cin, genre);
    }

    //overriding displayInfo() in derived class
    void displayInfo() const override
    {
        LibraryItem::displayInfo();
        cout << "Genre: " << getGenre() << endl;
    }
};

//Magazine private member variables and public member functions
class Magazine : public LibraryItem
{
private:
    //relevant attribute for magazine: issue number
    int issueNumber;

public:
    //default constructor
    Magazine() : LibraryItem()
    {
        issueNumber = 0;
    }

    //overload constructor
    Magazine(string t, string a, string i, bool ib, int issueNumber)
        : LibraryItem(t, a, i, ib)
    {
        this->issueNumber = issueNumber;
    }

    //getter functions for issue number
    int getIssueNumber() const { return issueNumber; }

    void assignIssueNumber()
    {
        cout << "Issue number: ";
        cin >> issueNumber;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    //overriding displayInfo() in derived class
    void displayInfo() const override
    {
        LibraryItem::displayInfo();
        cout << "Issue Number: " << getIssueNumber() << endl;
    }
};

// load library items from file into the items vector
// returns false if file can�t be opened
inline bool loadData(const string& filename,
                     vector<LibraryItem*>& items)
{
    ifstream in(filename);
    if (!in.is_open()) return false;

    items.clear();
    string line;
    while (getline(in, line)) {
        stringstream ss(line);
        string type, title, author, id, statusStr, attr;
        getline(ss, type,      '|');
        getline(ss, title,     '|');
        getline(ss, author,    '|');
        getline(ss, id,        '|');
        getline(ss, statusStr, '|');
        getline(ss, attr,      '|');

        bool borrowed = (statusStr == "1");
        if (type == "Book") {
            items.push_back(new Book(title, author, id,
                                     borrowed, attr));
        }
        else if (type == "Magazine") {
            int issue = stoi(attr);
            items.push_back(new Magazine(title, author, id,
                                         borrowed, issue));
        }
    }
    return true;
}

// save all items back to file, overwriting previous data
// returns false if file can�t be created/opened
inline bool saveData(const string& filename,
                     const vector<LibraryItem*>& items)
{
    ofstream out(filename, ios::trunc);
    if (!out.is_open()) return false;

    for (auto item : items) {
        if (auto b = dynamic_cast<Book*>(item)) {
            out << "Book" << '|'
                << b->getTitle()   << '|'
                << b->getAuthor()  << '|'
                << b->getID()      << '|'
                << (b->getStatus()? '1':'0') << '|'
                << b->getGenre()   << '\n';
        }
        else if (auto m = dynamic_cast<Magazine*>(item)) {
            out << "Magazine" << '|'
                << m->getTitle()        << '|'
                << m->getAuthor()       << '|'
                << m->getID()           << '|'
                << (m->getStatus()? '1':'0') << '|'
                << m->getIssueNumber()  << '\n';
        }
    }
    return true;
}

#endif

